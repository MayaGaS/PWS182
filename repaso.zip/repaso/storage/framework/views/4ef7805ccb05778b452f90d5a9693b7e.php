<div class="card">
    <div class="card-header text-center">
    Libreria Garrido © <?php echo e(now()->format('d/m/Y')); ?>

    </div>
</div>
<?php /**PATH C:\laragon\www\PWS182\repaso\resources\views/partials/footer.blade.php ENDPATH**/ ?>