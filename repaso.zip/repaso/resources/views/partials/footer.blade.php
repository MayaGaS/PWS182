<div class="card">
    <div class="card-header text-center">
    Libreria Garrido © {{ now()->format('d/m/Y') }}
    </div>
</div>
